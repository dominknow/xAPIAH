
/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://saas.dev.dominknow.com/quarterly/activities/course/102478";

//
// CourseName for the activity
//
TC_COURSE_NAME = {
    "en-US": "AHTest"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
    "en-US": ""
};

//
// Pre-configured LRSes that should receive data, added to what is included
// in the URL and/or passed to the constructor function.
//
// An array of objects where each object may have the following properties:
//
//    endpoint: (including trailing slash '/')
//    auth:
//    allowFail: (boolean, default true)
//
TC_RECORD_STORES = [
	
//    {
//        "endpoint": "https://watershedlrs.com/api/organizations/1812/lrs/",
//        "auth": "Basic NTliMjRmNzM2NTVjM2Q6MDI2ZTM5OTY1ODcyZjg="
//        }
    {
	"endpoint": "http://ll.dominknow.com/data/xAPI/",
	"auth": "Basic ZmRkODZhOTE3MzI4ODcxMGU1OTFmOGIzN2VkYmZmYTY4MTI2OGUxNjowZWRmMzcwMGMwMzc5MWZhMmE1MTU1MWM2M2FmZGQyYWE5YWJkNmVj"
	} 
];
