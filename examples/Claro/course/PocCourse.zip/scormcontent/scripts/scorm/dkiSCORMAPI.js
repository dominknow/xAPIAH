if(!DKI) {
	var DKI = {};
}
DKI.scormAPI = function(cfg){
	this.scormAPI = cfg.launchInNewWindow ? window.opener.parent : window.parent;
	this.supportHighASCII = cfg.supportHighASCII ? true : false;
};

DKI.scormAPI.prototype.onPlayerResize = function(cfg,cb){
	var win = this.scormAPI;
	var deltaX = cfg.totalWidth - $(win).width();
	var deltaY = cfg.totalHeight - $(win).height();
	win.top.resizeBy(deltaX, deltaY);
	if(screen.availHeight <= 800){
		var resize = function(){
			if (cfg.totalHeight > $(win).height()) {
				var newSize = $(win).height() - cfg.barHeight;
				cb.data.args = [newSize];
				cb.callback(cb.data);
				//We only want to run this function once right after our resize. So now we turn it off
				$(win).off("resize", this);
			}
		};//Use jQuery proxy to send the resize function as the 'this' scope
		$(win).resize($.proxy(resize, resize));
	}
};
DKI.scormAPI.prototype.onPlayerResize.async = true;

DKI.scormAPI.prototype.getDataStorageInit = function(){
	var cfg = {
		"GetBookmark"             : this.scormAPI.GetBookmark(),
		"GetPassingScore"         : this.scormAPI.GetPassingScore(),
		"GetDataChunk"            : this.scormAPI.GetDataChunk(),
		"GetStatus"               : this.scormAPI.GetStatus(),
		"LESSON_STATUS_PASSED"    : this.scormAPI.LESSON_STATUS_PASSED,
		"LESSON_STATUS_FAILED"    : this.scormAPI.LESSON_STATUS_FAILED,
		"LESSON_STATUS_COMPLETED" : this.scormAPI.LESSON_STATUS_COMPLETED,
		"GetStudentID"            : this.scormAPI.GetStudentID(),
		"objLMS"                  : this.scormAPI.objLMS
	};
	if(this.scormAPI.tincan && this.scormAPI.tincan.activity){
		cfg.rootXAPIActivity = this.scormAPI.tincan.activity;
	}
	return cfg;
};

DKI.scormAPI.prototype.saveCompletion = function(progress,dataChunk,pageInfo) {
	if(pageInfo){
		this.scormAPI.SetBookmark(pageInfo.id,pageInfo.title);
	}
	this.scormAPI.SetProgressMeasure(progress);
	this.scormAPI.SetDataChunk(dataChunk);
	this.scormAPI.CommitData();
};
DKI.scormAPI.prototype.scoreTest = function(type,args){
	switch(type){
		case 1: 
			this.scormAPI.RecordTrueFalseInteraction.apply(this.scormAPI,args);
		break;
		case 2: 
			for(var i = 0; i < args.actualChoice.length; i++){
				args.actualChoice[i] = this.createResponseIdentifier(args.actualChoice[i].strShort,args.actualChoice[i].strLong);
			}
			for(i = 0; i < args.correctChoice.length; i++){
				args.correctChoice[i] = this.createResponseIdentifier(args.correctChoice[i].strShort,args.correctChoice[i].strLong);
			}
			this.scormAPI.RecordMultipleChoiceInteraction(
				args.id,
				args.actualChoice,
				args.isCorrect,
				args.correctChoice,
				args.questionBody,
				args.questionWeight,
				args.questionLatency);
		break;
		case 3: 
			this.scormAPI.RecordFillInInteraction.apply(this.scormAPI,args);
		break;
		case 4: 
			this.scormAPI.RecordFillInInteraction.apply(this.scormAPI,args);
		break;
		case 5: 
			for(var i = 0; i < args.actualChoice.length; i++){
				args.actualChoice[i] = this.createResponseIdentifier(args.actualChoice[i].strShort,args.actualChoice[i].strLong);
			}
			for(i = 0; i < args.correctChoice.length; i++){
				args.correctChoice[i] = this.createResponseIdentifier(args.correctChoice[i].strShort,args.correctChoice[i].strLong);
			}
			this.scormAPI.RecordSequencingInteraction(
				args.id,
				args.actualChoice,
				args.isCorrect,
				args.correctChoice,
				args.questionBody,
				args.questionWeight,
				args.questionLatency);
		break;
		case 6: 
			for(var i =0; i < args.matchCall.length; i++){
				var match = args.matchCall[i];
				match[1] = this.createResponseIdentifier(match[1].strShort,match[1].strLong);
				match[2] = this.createResponseIdentifier(match[2].strShort,match[2].strLong);
				this.scormAPI.MatchingResponse.call(match[0],match[1],match[2]);
			}
			this.scormAPI.RecordMatchingInteraction(
				args.id,
				args.actualChoice,
				args.isCorrect,
				args.correctChoice,
				args.questionBody,
				args.questionWeight,
				args.questionLatency);
		break;
	}
};

DKI.scormAPI.prototype.process = function(data, callback){
	var proc = this.getMember(data.action);
	if(proc){
		var async = false;

		async = proc.member.async ? true : false;
		data.args.push({callback : callback, data : data});
		data.args = proc.member.apply(proc.scp,data.args);

		if(!async){
			callback(data);
		}
	}
};

DKI.scormAPI.prototype.getMember = function(ns){
	var member = this,
		walk   = function(path,src){
			var scp = src,
				path = path.split("."),
				mem = path.shift();
			if(typeof src[mem] === "undefined"){
				return undefined;
			}
			else if(typeof src[mem] !== "object" || path.length === 0){
				return {scp : scp, member : src[mem]};
			}
			else{
				return walk(path.join("."),src[mem]);
			}
		};
	member = walk(ns,member);
	return typeof member === "undefined" ? walk(ns,this.scormAPI) : member;
};

DKI.scormAPI.prototype.doExit = function(lessonStatus){
	if (this.scormAPI.strLMSStandard === "SCORM2004" &&
			(
			 lessonStatus === "passed" ||
			 lessonStatus === "failed" ||
			 lessonStatus === "complete"
			)
		)
	{
		this.scormAPI.SCORM2004_SetNavigationRequest("exitAll");
	}
	this.scormAPI.ConcedeControl();
};
/**
 * Wrapper for SCORM API call. Used to evalute on a publishing profile
 *
 * @param {String} strShort The short identifier for the option, as defined by the SCORM API
 * @param {String} strLong The long identifier for the option, as defined by the SCORM API
 */
DKI.scormAPI.prototype.createResponseIdentifier =  function(strShort, strLong){
	/* We use encodeURIComponent because the string isn't a URI, by any means. It's just user entered data. 
	 * If we don't encode it, the High ASCII characters will be lost in the CreateResponseIdentifiers function.
	*/
	strLong = this.supportHighASCII ? encodeURIComponent(strLong) : strLong;
	return this.scormAPI.CreateResponseIdentifier(strShort, strLong);
};
