	DKI.SCORMDataStorage = DKI.DataStorage.extend({
	/**
	 * Implementation of a datastorage object, with SCORM data storage/retrieval
	 * @class DKI.SCORMDataStorage
	 * @constructor
	 * @extends DKI.DataStorage
	 * @param {Object} courseStructure The structure of the course pacage
	 * @param {Object} behaviour The package's runtime behaviour configuration
	 * @param {Object} aStrings M17N string values
	 * @param {Object} scormAPI The object providing SCORM methods
	 */
	init: function (courseStructure, behaviour, aStrings, initCfg, scormInterface) {
		this._parent(courseStructure, behaviour, aStrings);
		/**
		 * The object providing SCORM api methods
		 * @property {Object}
		 */
		this.scormInterface	        = scormInterface;
		this.bookmark      	        = initCfg.GetBookmark;
		this.passingScore   	    = initCfg.GetPassingScore;
		this.status                 = initCfg.GetStatus;
		this.dataChunk              = initCfg.GetDataChunk;
		this.statusPassed           = initCfg.LESSON_STATUS_PASSED;
		this.statusFailed           = initCfg.LESSON_STATUS_FAILED;
		this.statusComplete         = initCfg.LESSON_STATUS_COMPLETED;
		this.studentId              = initCfg.GetStudentID;
		this.objLMS                 = initCfg.objLMS;
		this.storedContentVariables = {};	
		this.rootXAPIActivity = null;	
		if(initCfg.rootXAPIActivity){
			this.rootXAPIActivity = initCfg.rootXAPIActivity;
		}
	},

	setContentVariable: function (name, value, preventStorage) {
		this._parent(name, value);
		if(!preventStorage){
			this.storedContentVariables[name] = this._parent.getContentVariable(name);
		}
	},

	/**
	 * Factory method, creates an Assessment object for a given module
	 * @param {Object} module The module the assessment is being created for
	 * @param {String} prePost One of "pre" or "post", for the assessment type
	 * @param {Object} test The test object
	 * @returns {DKI.SCORMAssessment} The new assessment object
	 */
	createAssessment: function(module, prePost, test) {
		return new DKI.SCORMAssessment(module, prePost, test, this.scormInterface);
	},
	/**
	 * Initializes event handlers. Calls the underlying
	 * {@link DKI.DataStorage#initEvents}
	 */
	initEvents: function () {
		var that = this;
		$(this).on(DKI.DataStorage.events.pageSelected, function (e, subeo) {
			that.saveCompletion(subeo.page);
		});
		this.setupXAPITriggers();
		this._parent.initEvents();
	},
	/**
	 * Loads previous completion from {@link DKI.SCORMDataStorage#scormAPI}.
	 * If the 'autoResume' parameter is 'on', will automatically resume at last
	 * completion. If the 'autoResume' parameter is 'prompt', will prompt user
	 * to resume. Otherwise, will launch the first page of the course. 
	 *
	 * See DKI.DataStorage#autoResume
	 *
	 * @param {String} autoResume If 'on', will jump automatically. If
	 * 'prompt', will prompt the user to jump.
	 */
	loadCompletion: function (autoResume) {
		if (this.bookmark === "") {
			this.bookmark = null;
		}
		var passMark = this.passinScore;
		var courseStatus = this.status;
		var chunkData = this.dataChunk;
		var data = {
			completion: {
				m: [],
				o: [],
				s: [],
				t: []
			},
			contentVariables: {}
		};
		if(chunkData !== ""){
			data = JSON.parse(chunkData);	
			//hook for new stuff added with the SOW.. 
			if(!data.completion){
				data = {
					completion: data
				};
			}
			if(data.contentVariables){
				this.contentVariables = data.contentVariables;
				this.storedContentVariables = this.contentVariables;
			}
		}
		var completionObject;		
		var i;
		if (passMark > 0) {
			this.passMark = passMark;
		}
		if (
			courseStatus === this.statusPassed ||
			courseStatus === this.statusFailed ||
			courseStatus === this.statusComplete
			) {
			completionObject = data.completion;
			this.markCourseComplete();
			//Loop through tests
			for (i = 0; i < completionObject.t.length; i ++) {
				if (completionObject.t[i].pre) {
					this.setModulePre(completionObject.t[i].id, completionObject.t[i].pre);
				}
				if (completionObject.t[i].post) {
					this.setModulePost(completionObject.t[i].id, completionObject.t[i].post);
				}
			}
		}
		else if (chunkData !== ""){
			completionObject = data.completion;
			var that = this;
			for (i = 0; i < completionObject.m.length; i ++) {
				this.markModuleComplete(completionObject.m[i]);
			}
			for (i = 0; i < completionObject.o.length; i ++) {
				this.markObjectComplete(completionObject.o[i]);
			}
			if(completionObject.p){
				completionObject.s = [];
				$.each(completionObject.p, function(index,item){
					var subeo = that._parent.getSubeoFromPage(item);
					if(subeo){
						completionObject.s.push(subeo.subeoid);
					}
				});
			}
			$.each(completionObject.s, function(index,item){
				that.markSubeoComplete(item);
			});		
			for (i = 0; i < completionObject.t.length; i ++) {
				if (completionObject.t[i].pre) {
					this.setModulePre(completionObject.t[i].id, completionObject.t[i].pre);
				}
				if (completionObject.t[i].post) {
					this.setModulePost(completionObject.t[i].id, completionObject.t[i].post);
				}
			}
			this.checkCourseComplete();
		}
		this._parent.loadCompletion(autoResume);
	},
	/**
	 * Rebuilds a module's weighting as part of overall course test. Used
	 * when retrieving suspend data for modules that don't have weightingo
	 * @param {Object} module The module to weight
	 * @returns {Number} totalQuestions * 10
	 */
	reconstructWeight: function (module) {
		var totalQuestions = 0;
		if (typeof module != "object") {
			module = this.findModule(module);
		}

		for (var i = 0; i < module.objects.length; i += 1) {
			if (module.objects[i].randQuest <= module.objects[i].questions.length) {
				totalQuestions += module.objects[i].randQuest;
			}
			else {
				totalQuestions += module.objects[i].questions.length;
			}
		}

		//We assume default weight of 10 for legacy module suspend strings
		return totalQuestions * 10;
	},
	/**
	 * Saves page completion data via scorm API. Also sets progress mesure and
	 * commits suspend data
	 * @param {Object} page The page to store completion for
	 */
	saveCompletion: function (page) {
		var args = [this.getCourseCompletion(true) / 100,this.serializeDataChunk()];
		if(page){
			args.push({id : page.pageid, title : page.title});
		}
		else{
			args.push(null);
		}
		this.scormInterface.process("saveCompletion",args);
	},
	/**
	 * Serializes current course completion for scorm suspend data
	 * @returns {String} Course completion serialized as a JSON string
	 */
	serializeDataChunk: function () {
		var currentMod, currentObj, testRecord;
		var completionObj = {
			m: [],
			o: [],
			s: [],
			t: []
		};
		for (var i = 0; i < this.courseStructure.modules.length; i ++) {
			currentMod = this.courseStructure.modules[i];
			if (currentMod.complete) {
				completionObj.m[completionObj.m.length] = currentMod.loid;
			}
			else {
				for (var j = 0; j < currentMod.objects.length; j ++) {
					currentObj = currentMod.objects[j];
					if (currentObj.complete) {
						completionObj.o[completionObj.o.length] = currentObj.objectid;
					}
					else {
						for (var k = 0; k < currentObj.subeos.length; k ++) {
							if (currentObj.subeos[k].complete) {
								completionObj.s[completionObj.s.length] = currentObj.subeos[k].subeoid;
							}
						}
					}
				}
			}
			if (currentMod.pre || currentMod.post) {
				testRecord = {
					id: currentMod.loid
				};
				if (currentMod.pre) {
					testRecord.pre = currentMod.pre;
				}
				if (currentMod.post) {
					testRecord.post = currentMod.post;
				}
				completionObj.t[completionObj.t.length] = testRecord;
			}
		}
		var storedData = {
			completion: completionObj
		};
		if (this.objLMS.Standard !== "SCORM") {
			storedData.contentVariables = this.storedContentVariables;
		};
		return JSON.stringify(storedData);
	},
	/**
	 * Sets pre-test score for a module
	 * @param {Number | Object} moduleID The Id of the module, or the actual
	 * module.
	 * @param {Object | Number} preScore If a number, weight/ponts are calculated
	 * @param {Number} preScore.score The pre-test score
	 * @param {Number} [preScore.weight] The pre-test weight. Calculcated with
	 * {@link DKI.SCORMDataStorage#reconstructWeight}
	 * @param {Number} [preScore.points] The pre-test points. If not provided,
	 * calculated as (score / 100) * weight)
	 */
	setModulePre: function (moduleID, preScore) {
		var module = typeof moduleID == "object" ? moduleID : this.findModule(moduleID);
		var score = typeof preScore == "object" ? preScore.score : preScore;
		var weight = typeof preScore == "object" ? preScore.weight : this.reconstructWeight(module);
		var points = typeof preScore == "object" ? preScore.points : parseFloat(((score / 100) * weight).toFixed(1), 10);

		if (points == Math.round(points)) {
			points = parseInt(points, "10");
		}

		module.pre = {
			score: score
			,weight: weight
			,points: points
		};
	},
	/**
	 * Sets post-test score for a module
	 * @param {Number | Object} moduleID The Id of the module, or the module itself.
	 * @param {Object} postRecord
	 * @param {Number} postRecord.score The post-test score
	 * @param {Number} [postRecord.weight] The post-test weight. Recalculated by
	 * calling {@link DKI.SCORMDataStorage#reconstructWeight}
	 */
	setModulePost: function (moduleID, postRecord) {
		var module = typeof moduleID == "object" ? moduleID : this.findModule(moduleID);
		if (!postRecord.weight) {
			postRecord.weight = this.reconstructWeight(module);
		}
		if (!postRecord.points) {
			postRecord.points = parseFloat(((postRecord.score / 100) * postRecord.weight).toFixed(1), 10);
		}
		if (postRecord.points == Math.round(postRecord.points)) {
			postRecord.points = parseInt(postRecord.points, "10");
		}
		module.post = postRecord;
		if (this.courseStructure.testonly && this.remainingPostAttempts(module) == "0") {
			module.complete = true;
		}
	},
	/**
	 * Marks the course as complete
	 */
	markCourseComplete: function () {
		for (var i = 0; i < this.courseStructure.modules.length; i ++) {
			this.markModuleComplete(this.courseStructure.modules[i]);
		}
	},
	/**
	 * Overrides the parent method, saving completion information afterward
	 *
	 * See DKI.DataStorage#createTest
	 */
	createTest: function (moduleID, prePost) {
		this._parent.createTest(moduleID, prePost);
		this.saveCompletion();
	},
	//Event handler functions
	/**
	 * Overrides the parent method, saving completing/progress/score to scorm API
	 *
	 * See DKI.DataStorage#onCourseComplete
	 */
	onCourseComplete: function () {
		this._parent.onCourseComplete();		
		switch(playerBehaviour.completionStatus){
			case 1: 
				//default behavior
				switch (this.lessonStatus) {
					case "passed":
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
						this.scormInterface.process("SetPassed");
						break;
					case "failed":
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
						this.scormInterface.process("SetFailed");
						break;
					case "complete":
						this.scormInterface.process("SetReachedEnd");
						this.scormInterface.process("SetPassed");
						break;
				}
				break;
			case 2:
				//Completed/incomplete
				if(this.lessonStatus == "complete" || this.lessonStatus == "passed"){
					if(this.lessonStatus == "passed"){
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					}
					this.scormInterface.process("SetReachedEnd");
				}
				break;
			case 3:
				//Completed/Failed
				if(this.lessonStatus == "complete" || this.lessonStatus == "passed"){
					if(this.lessonStatus == "passed"){
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					}
					this.scormInterface.process("SetReachedEnd");
				}
				else if(this.lessonStatus == "failed"){
					this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					this.scormInterface.process("SetFailed");
				}
				break;
			case 4:
				//Passed/Failed				
				if(this.lessonStatus == "complete" || this.lessonStatus == "passed"){
					if(this.lessonStatus == "passed"){
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					}
					this.scormInterface.process("SetPassed");
				}
				else if(this.lessonStatus == "failed"){
					this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					this.scormInterface.process("SetFailed");
				}
				break;
			case 5:
				//Passed/Incomplete
				if(this.lessonStatus == "complete" || this.lessonStatus == "passed"){
					if(this.lessonStatus == "passed"){
						this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
					}
					this.scormInterface.process("SetPassed");
				}
				break;
		}
		
		var that = this;
		this.scormInterface.process("GetStatus",[],function(data){
			that.status = data;
		});				

		this.saveCompletion();
	},
	/**
	 * Overrides the parent method, saving completion etc. to scorm API
	 *
	 * See DKI.DataStorage#onAssessmentComplete
	 */
	onAssessmentComplete: function () {
		var nextModule;
		this._parent.onAssessmentComplete();
		if (this.objLMS.Standard === "SCORM2004") {
			this.scormInterface.process("SetScore",[this.getCourseScore(), 100, 0]);
		}
		if (this.courseStructure.testonly) {
			nextModule = this.getNextModule(this.assessment.module);
			if (nextModule) {
				this.scormInterface.process("SetBookmark",[nextModule.loid, nextModule.name]);
			}
			else {
				this.scormInterface.process("SetBookmark",["", ""]);
			}
		}
		this.saveCompletion();
	},
	/**
	 * Overrides the parent method, gets Id from the scorm API
	 *
	 * See DKI.DataStorage#getUserID
	 */
	getUserID: function () {
		return this.studentId;
	},
	/**
	 * Get's a member from datastorage
	 */
	get      : function(key){
		return this[key];
	},
	doExit : function(){
		this.scormInterface.process("doExit",[this.lessonStatus],$.proxy(function(){
			if (this.behaviour.launchInNewWindow) {
				window.close();
			}
		},this));
	},
	setupXAPITriggers: function(){
		var that = this;
		$(document).on(
			DKI.ContentPage.events.elementDragStarted + " " +
			DKI.ContentPage.events.elementDragDropped + " " +
			DKI.ContentPage.events.elementDropOut + " " +
			DKI.ContentPage.events.elementDropOver + " ", function(e){		
			var triggerDisplays = {
				"ELEMENT_DRAG_STARTED": {
					"en-us": "started dragging"
				},
				"ELEMENT_DRAG_DROPPED": {
					"en-us": "dropped"
				},
				"ELEMENT_DROP_OVER": {
					"en-us": "dragged over"
				},
				"ELEMENT_DROP_OUT": {
					"en-us": "dragged out of"
				}
			};
			var element = that.getElement($(e.target).data("id"));
			var title = element.title;
			var description = element.description;
			var activityId = settings.activityRootURL + "element/" + element.elementid;
			if(element.upload_id && element.upload_id != ""){
				activityId = settings.activityRootURL + "asset/" + element.upload_id;
				title = element.asset_title;
				description = element.asset_description;
			}
			var display = triggerDisplays[e.type];			
			contentApi.sendXAPIStatement({				
				"verb": {
					"id": "http://adlnet.gov/expapi/verbs/interacted",
					"display": display
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://activitystrea.ms/schema/1.0/event"
					},
					"objectType": "Activity"
				}
			});
		});
		$(document).on(DKI.ContentPage.events.actionFired, function(e, obj){
			var triggerDisplays = {
				"click": {
					"en-us": "clicked"
				},
				"dblClick": {
					"en-us": "double clicked"
				},
				"rightClick": {
					"en-us": "right clicked"
				},
				"mouseenter": {
					"en-us": "moused over"
				},
				"mouseleave": {
					"en-us": "moused out of"
				}
			};
			if(!obj.action.elementId || !triggerDisplays[obj.action.trigger]){
				return;
			}
			var element = that.getElement(obj.action.elementId);
			var title = element.title;
			var description = element.description;
			var activityId = settings.activityRootURL + "element/" + element.elementid;			
			if(element.upload_id && element.upload_id != ""){
				activityId = settings.activityRootURL + "asset/" + element.upload_id;
				title = element.asset_title;
				description = element.asset_description;
			}
			var display = triggerDisplays[obj.action.trigger];			
			contentApi.sendXAPIStatement({
				"verb": {
					"id": "http://adlnet.gov/expapi/verbs/interacted",
					"display": display
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://activitystrea.ms/schema/1.0/event"
					},
					"objectType": "Activity"
				}
			});
		});
		$(document).on(DKI.ContentPage.events.media.started, function(e, obj){			
			var element = that.getElement(obj.elementId);
			var title = element.asset_title;
			var description = element.asset_description;
			var activityId = settings.activityRootURL + "asset/" + element.upload_id;			
			contentApi.sendXAPIStatement({
				"verb": {
					"id": "http://activitystrea.ms/schema/1.0/start",
					"display": {
						"en-us": "started"
					}
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://adlnet.gov/expapi/activities/media"
					},
					"objectType": "Activity"
				}
			});
		});
		$(document).on(DKI.ContentPage.events.media.paused, function(e, obj){			
			var element = that.getElement(obj.elementId);
			var title = element.asset_title;
			var description = element.asset_description;
			var activityId = settings.activityRootURL + "asset/" + element.upload_id;			
			contentApi.sendXAPIStatement({
				"verb": {
					"id": "http://id.tincanapi.com/verb/paused",
					"display": {
						"en-us": "paused"
					}
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://adlnet.gov/expapi/activities/media"
					},
					"objectType": "Activity"
				}
			});
		});
		$(document).on(DKI.ContentPage.events.media.played, function(e, obj){			
			var element = that.getElement(obj.elementId);
			var title = element.asset_title;
			var description = element.asset_description;
			var activityId = settings.activityRootURL + "asset/" + element.upload_id;			
			contentApi.sendXAPIStatement({
				"verb": {
					"id": "http://activitystrea.ms/schema/1.0/play",
					"display": {
						"en-us": "played"
					}
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://adlnet.gov/expapi/activities/media"
					},
					"objectType": "Activity"
				}
			});
		});
		$(document).on(DKI.ContentPage.events.media.ended, function(e, obj){			
			var element = that.getElement(obj.elementId);
			var title = element.asset_title;
			var description = element.asset_description;
			var activityId = settings.activityRootURL + "asset/" + element.upload_id;			
			contentApi.sendXAPIStatement({
				"verb": {
					"id": "http://activitystrea.ms/schema/1.0/consume",
					"display": {
						"en-us": "consumed"
					}
				},
				"object": {
					"id": activityId,
					"definition": {
						"name": {
							"en-US": title
						},
						"description": {
							"en-US": description
						},
						"type": "http://adlnet.gov/expapi/activities/media"
					},
					"objectType": "Activity"
				}
			});
		});
	}
});
