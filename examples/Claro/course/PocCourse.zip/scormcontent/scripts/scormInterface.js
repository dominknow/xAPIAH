DKI.scormInterface = $.Class({
	init : function(cfg){
		this.localAPI = !cfg.isStub;
		this.queue = {};
		if(this.localAPI){
			this.scormAPI = cfg.scormAPI; 
		}else if(Porthole && this.getQueryParameters("portURL")) {
			this.scormAPI = new Porthole.WindowProxy(this.getQueryParameters("portURL"));
			this.scormAPI.addEventListener(this.proxyMessageReceived);
		}
		$(document).on(DKI.scormInterface.events.messageReceived, $.proxy(this.resolveQueue,this));
	}
});

DKI.scormInterface.prototype.getQueryParameters = function(name){
	 name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
};

DKI.scormInterface.prototype.proxyMessageReceived = function(m){
	$(document).trigger(DKI.scormInterface.events.messageReceived,[m]);
};

DKI.scormInterface.prototype.resolveQueue = function(e,m){
	var data = m.data;
	if(data.id){
		this.queue[data.id].callback(m.data.args);
		delete this.queue[data.id];
	}
};

DKI.scormInterface.prototype.process = function(action,args,callback){
	var id = this.createGUID();
	this.queue[id] = {
		callback : callback ? callback : function(){}
	};
	this.callAPI(action,args,id);
};

DKI.scormInterface.prototype.callAPI = function(action,args,id){
	var defArgs = {
		action  : "",
		args    : [],
		id      : 0
	};
	var cfg = DKI.applyIf({"action" : action, args : args, id : id}, defArgs);
	if(this.localAPI){
		 this.scormAPI.process(cfg, function(ret){
			$(document).trigger(DKI.scormInterface.events.messageReceived,[{data:{id:id,args:ret.args}}]);
		});
	}else{
		this.scormAPI.post(cfg);
	}
};


DKI.scormInterface.prototype.createGUID = function (separator) {						   
    var delim = separator || "-";
    function S4() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    }
    return (S4() + S4() + delim + S4() + delim + S4() + delim + S4() + delim + S4() + S4() + S4());
};

DKI.scormInterface.events = {
	messageReceived : "SCORM_API_MESSAGE_RECEIVED"
}