/**
 * Singleton representation of the feedback panel control
 * @author	Keith Chadwick
 * @singleton
 * @class
 */
DKI.FeedbackPanel = function(){
	var _oActivePage = null;			// local pointer to the current active page or question object		
	var _store = {};				// store pointer
	var feedbackInput;
	var feedbackSubmit;
	var presentationPlayer;
	var pinnedElementId;
	var notesUpvoted = [];
	
	
		
	/**
	 * Initializes the Feedback panel
	 * @method	init
	 * @member DKI.FeedbackPanel
	 * @param   player The course player object.
	 * @param	elementID	string id of element to render panel content to
	 * @param	dataStore	courseStore object
	 * @return	true
	 */
	var initialize = function(player, dataStorage,astrings){
		presentationPlayer = player;
		strings = astrings;
		_store = dataStorage;		
		
		var toolbar = Handlebars.compile(DKI.templates.feedbackPanel.toolbar)({			
			strings: strings			
		});
		$("body").append(toolbar);
		var feedbackTab = $("#feedbackTab");		
		var endReviewTab = $("#endReviewTab");
		var pinFeedback = $("#pinFeedback");
		var answerKey = $("#answerKey");
		feedbackTab.css("display", "block");	
		
		$("#reviewerTabContainer").draggable({
			containment: "body"
		});

		feedbackTab.on(player.settings.clickEvent, function (e) {
			pinnedElement = null;
			e.stopPropagation();
			return false;
		});
		addTooltip(feedbackTab, {
			position: "top-right",
			onlyOne: false
		});
		feedbackTab.attr("title", "Review Feedback");

		if(player.dataStorage.courseStructure.isDebug){
			endReviewTab.css("display", "block");
		}
		else{
			endReviewTab.remove();
		}
		endReviewTab.on(player.settings.clickEvent + " keypress", function (e) {
			onReviewEnded();
		});
		pinFeedback.css("display", "block");
		pinFeedback.on(player.settings.clickEvent + " keypress", function (e) {
			if(!pinFeedback.isDisabled()){
				onPinClicked(e);
			}
		});

		answerKey.hide().tooltipster({
			contentAsHTML: true,
			functionBefore: function(origin, continueTooltip){
				var content = Handlebars.compile(DKI.templates.feedbackPanel.answerKey)({
					assessment: contentApi.getCurrentAssessment(),
					question: presentationPlayer.contentPage.current.question,
					strings: strings
				});
				origin.addClass("tooltip-open");
				origin.tooltipster('content', content);							
				continueTooltip();				
				var tooltipBody = $(origin.tooltipster("elementTooltip"));
				$(".question-option-element-link", tooltipBody).on("mouseenter", function(){
					var link = $(this);
					contentApi.getElementWrapper(link.data("id")).addClass("feedback-highlighted");
				});
				$(".question-option-element-link", tooltipBody).on("mouseleave", function(){
					var link = $(this);
					contentApi.getElementWrapper(link.data("id")).removeClass("feedback-highlighted");
				});
				$("#closeAnswerKey", tooltipBody).on(settings.clickEvent, function(){
					answerKey.tooltipster("hide");
				});
			},
			functionAfter: function(origin){
				origin.removeClass("tooltip-open");
			},
			trigger: "custom",
			onlyOne: false,
			theme: "tooltipster-claro",
			interactive: true,
			contentCloning: false,
			position: "top-left",
			positionTracker: true,
			updateAnimation: false
		});

		answerKey.on("click", function(){			
			if(answerKey.hasClass("tooltip-open")){
				answerKey.tooltipster("hide");
			}
			else if(!answerKey.isDisabled()){
				answerKey.tooltipster("show");
			}
		});	


		$(document).on(DKI.ContentPage.events.started, function(e, pageInstance){
			appendElementFeedback(pageInstance);
			_oActivePage = pageInstance.page;
			feedbackTab.data("page_notes", _oActivePage.notes);
			$(".element-feedback-icon.tooltip-open").tooltipster("hide");
			if(feedbackTab.hasClass("tooltip-open")){
				feedbackTab.tooltipster("show");
			}
			if(answerKey.hasClass("tooltip-open")){
				answerKey.tooltipster("show");
			}

			feedbackTab.enable().tooltipster("enable");
			pinFeedback.enable();	
			if(player.contentPage.current.question){
				answerKey.enable().tooltipster("enable");
				answerKey.attr("title", "Assessment Details");
			}
			else{
				answerKey.disable().tooltipster("disable");
				answerKey.removeAttr("title");
			}
		});

		
		$(document).on([DKI.EndCourse.events.started, DKI.EndModule.events.started, DKI.EndTest.events.started].join(" "), function(){
			$(".element-feedback-icon.tooltip-open").tooltipster("hide");
			answerKey.disable().tooltipster("disable");
			feedbackTab.disable().tooltipster("disable");
			pinFeedback.disable();
		});

		return true;	
	}; //-> end Initialize	
	var reposition = function(tooltipBody){
		tooltipBody = $(tooltipBody);
		var offset = tooltipBody.offset();
		if(offset.top < 0){
			offset.top = 0;
		}
		if((offset.top + tooltipBody.height()) > $("body").height()){
			offset.top = $("body").height() - tooltipBody.height();
		}
		if(offset.left < 0){
			offset.left = 0;
		}
		if((offset.left + tooltipBody.width()) > $("body").width()){
			offset.left = $("body").width() - tooltipBody.width();
		}
		tooltipBody.offset(offset);
	};
	var addTooltip = function(icon, options){
		
		var cfg = DKI.applyIf(options?options:{},{
			contentAsHTML: true,
			functionBefore: function(origin, continueTooltip){
				var notes = _oActivePage.notes;
				if(icon.hasClass("element-feedback-icon")){
					notes = getNotesForElement(icon.closest(".dki-authoring-element").data("id"));
				}
				var content = $(Handlebars.compile(DKI.templates.feedbackPanel.tooltipContent)({
					o: {
						notes: notes
					},
					strings: strings
				}));
				origin.addClass("tooltip-open");
				$.each(notesUpvoted, function(){
					var id = this.toString();
					$(".feedback-note-body-wrapper[data-id='" + id + "'] .feedback-note-action.upvote", content).css("visibility", "hidden");
				});
				origin.tooltipster('content', content);
				if(origin.hasClass("reviewerTabButton")){
					$(content).find(".feedback-closeFeedbackTab").eq(0).attr("id", "closeToolbarFeedbackTab");
				}
				else{
					var currentPinElementId = pinnedElement.eq(0).attr("id");
					$(content).find(".feedback-closeFeedbackTab").eq(0).attr("data-pinelement-id", currentPinElementId);
					$(content).find(".feedback-closeFeedbackTab").eq(0).addClass("feedback-closeFeedbackTabOnElement");
				}
				continueTooltip();				
				var tooltipBody = $(origin.tooltipster("elementTooltip"));

				tooltipBody.on(player.settings.clickEvent, ".feedback-btnSubmit", function(){
					if(!$(this).isDisabled()){
						onFeedbackSubmit($(this).parent());
					}
					return false;
				});

				tooltipBody.on(player.settings.clickEvent, ".feedback-note-action.reply", function(){
					var feedbackReplyWrapper = $(this).parent().parent().find(".feedback-reply-wrapper");
					feedbackReplyWrapper.show();
					feedbackReplyWrapper.find("textarea").focus();
					reposition(tooltipBody);
				});

				tooltipBody.on(player.settings.clickEvent, ".feedback-note-action.edit", function(){
					var noteWrapper = $(this).parent().parent();
					var feedbackEditWrapper = noteWrapper.find(".feedback-edit-wrapper");
					var submitBtn = noteWrapper.find(".feedback-btnSubmit");
					feedbackEditWrapper.show();
					submitBtn.enable();
					feedbackEditWrapper.find("textarea").focus();
					$(".feedback-note-body, .feedback-note-action.edit", noteWrapper).hide();	
					reposition(tooltipBody);
				});

				tooltipBody.on(player.settings.clickEvent, ".feedback-note-action.delete", function(){
					if(window.confirm("Are you sure you want to delete this note and all it's comments?")){
						var wrapper = $(this).closest(".feedback-note-wrapper");						
						var id = wrapper.data("id");
						$(".feedback-note-wrapper[data-id='" + id + "']").remove();
						$.ajax({
							type: "POST",
							url: "../api/student.cfm/note/" + id,
							data: {
								active: false
							},
							success: function(){
								removeNote(id);
							}
						});
						reposition(tooltipBody);
					}
				});

				tooltipBody.on(player.settings.clickEvent, ".feedback-note-action.upvote", function(){
					var wrapper = $(this).closest(".feedback-note-body-wrapper");						
					var id = wrapper.data("id");
					var note = findNote(id);
					note.rating ++;
					wrapper.find(".feedback-note-rating").html(note.rating);
					$(this).css("visibility", "hidden");
					notesUpvoted.push(id);
					$.ajax({
						type: "PUT",
						url: "../api/student.cfm/note/" + note.id + "/upvote/"
					});
				});

				tooltipBody.on(player.settings.clickEvent, "#closeToolbarFeedbackTab", function(){
					$(feedbackTab).tooltipster("hide");
					return false;
				});

				tooltipBody.on(player.settings.clickEvent, ".feedback-closeFeedbackTabOnElement", function(){
					var pinnedElementId = $(this).data("pinelement-id");
					if(!this.getAttribute("id")){
						$('#' + pinnedElementId).find(".element-feedback-icon").tooltipster("hide");
						return false;
					}
					return false;
				});

				//dont show edit/delete for ntoes that arent mine.
				$(".feedback-note-wrapper[data-enteredby!='" + presentationPlayer.settings.userId + "']", tooltipBody).find(".feedback-note-action.edit, .feedback-note-action.delete").hide();
				$(".feedback-note-wrapper[data-enteredby='" + presentationPlayer.settings.userId + "']", tooltipBody).find(".feedback-note-action.upvote").css("visibility", "hidden");
				tooltipBody.find("textarea:first").focus();

				
			},
			functionAfter: function(origin){
				origin.removeClass("tooltip-open");
			},
			trigger: "click",
			onlyOne: false,
			theme: "tooltipster-claro feedback",
			interactive: true,
			contentCloning: false,
			position: "bottom-right",
			updateAnimation: false,
			positionTracker: true
		}, true);
		icon.tooltipster(cfg);
	}

		/**
	 * Handles the click/keypress of the end review button. Submits the end of
	 * the review back to the server.
	 * @param {Function} callback The callback function to execute after submitting
	 * the end of the review
	 */
	var onReviewEnded = function (callback) {
		var self = this;
		callback = callback === undefined? function(){} : callback;

		var	page = player.inAssessment ? player.dataStorage.assessment.currentQuestion.page : player.dataStorage.currentPage;

		var ajaxArgs = {
			type:"PUT",
			headers: {
				"Content-Type": "application/json; charset=UTF-8"
			},
			processData: false,
			url: "../ajax/course.cfm/endReview",
			dataType: "json",
			success: function(data) {
				callback(data);
				player.exitCourse();
			},
			failure: function(){
				alert("There was a problem ending your review period. Please try again.");
			},
			context: player
		};
		$.ajax(ajaxArgs);
		return false;
	};

	/**
	 * Handles the 'submission' for the feedback panel, performs actual submission 
	 * of data. Not a true event handler, this is implemented by a direct call to 
	 * the function. Not very decoupled.
	 * See DKI.FeedbackPanel
	 * @param {String} text The text entered by the reviewer
	 * @param {Function} callback Callback to handle the submission of the data
	 */
	var onFeedbackSubmit = function (wrapper) {
		if(wrapper.find("textarea")[0].value == ""){
			return false;
		}
		var submitBtn = wrapper.find(".feedback-btnSubmit");
		submitBtn.disable();
		var callback = function(note) {	
			var notesArray = _oActivePage.notes;
			if(note.parent_note_id && note.parent_note_id != ""){
				$.each(_oActivePage.notes, function(){
					if(this.id == note.parent_note_id){
						notesArray = this.notes;
						return false;
					}
				});					
			}
			notesArray.push(note);
			notesArray.sort(function(a,b){
				if(a.rating < b.rating) {
					return -1;
				}
				else if(a.rating > b.rating) {
					return 1;
				}
				return 0;
			});
			$(feedbackTab).data("page_notes", _oActivePage.notes);
			_oActivePage=_store.set(_oActivePage);
			var openTooltips = $(".feedback-tooltip-icon.tooltip-open");
			openTooltips.tooltipster("show", function(){
				reposition(openTooltips.tooltipster("elementTooltip"));
			});
			submitBtn.enable();
			return true;
		};
		var	page = player.inAssessment || player.inReview ? player.dataStorage.assessment.currentQuestion.page : player.dataStorage.currentPage.page;
		var type = "PUT";
		var url = "../api/student.cfm/page/" + page.pageid + "/note";
		if(pinnedElement){
			url = "../api/student.cfm/page/" + page.pageid + "/" + pinnedElement.data("id") + "/note";
		}
		var postData = {
			description: $("<div>" + wrapper.find("textarea")[0].value + "</div>").text(),
			reviewerUaSettings: JSON.stringify({
				UAString: navigator.userAgent,
				sniffer: dkiUA
			})
		};

		if(wrapper.data("parent_note_id")){
			url = "../api/student.cfm/note/" + wrapper.data("parent_note_id") + "/comment";
		}
		if(wrapper.data("id")){
			type = "POST";
			url = "../api/student.cfm/note/" + wrapper.data("id");
			callback = function(){
				
			};
			var note = findNote(wrapper.data("id"));
			note.description = postData.description;
			var bodyWrapper = $(".feedback-note-body-wrapper[data-id='" + note.id + "']");
			bodyWrapper.find(".feedback-note-body").html(note.description);
			bodyWrapper.find(".feedback-edit-wrapper").hide();
			bodyWrapper.find(".feedback-note-body, .feedback-note-action.edit").show();	
		}
		

		var ajaxArgs = {
			type: type,
			headers: {
				"Content-Type": "application/json; charset=UTF-8"
			},
			processData: false,
			url: url,
			dataType: "json",
			success: callback,
			context: player
		};
		if (/\S/.test(postData.description)) {
			ajaxArgs.data = JSON.stringify(postData);
			$.ajax(ajaxArgs);
		}

		return false;
	};

	var onPinClicked = function(e){
		var onElClicked = function(e){
			var elData = presentationPlayer.dataStorage.getElement($(this).data("id"));
			pinnedElement = $(this);
			$("body").removeClass("pin-feedback-mode");
			addElementTooltip($(this));
			var icon = $(this).find(".element-feedback-icon");
			icon.tooltipster("show", function(){
				reposition(icon.tooltipster("elementTooltip"));
			});
			e.stopImmediatePropagation();
			$(".dki-authoring-element").off(player.settings.clickEvent, onElClicked);
			$(".dkiContentFrame.current").off(e, onPageClicked);
			return false;
		}
		var onPageClicked = function(e){
			$("body").removeClass("pin-feedback-mode");			
			if(e){
				e.stopImmediatePropagation();
			}
			$(".dki-authoring-element").off(player.settings.clickEvent, onElClicked);
			$(".dkiContentFrame.current").off(player.settings.clickEvent, onPageClicked);
			return false;
		}
		if($("body").hasClass("pin-feedback-mode")){
				onPageClicked();
		}
		else{
			$("body").addClass("pin-feedback-mode");
			$(".dki-authoring-element").on(player.settings.clickEvent, onElClicked);
			$(".dkiContentFrame.current").on(player.settings.clickEvent, onPageClicked);
		}
		$(feedbackTab).tooltipster("hide");
		if($(answerKey).hasClass("tooltip-open")){
			$(answerKey).tooltipster("hide");
		}
		$(".element-feedback-icon.tooltip-open").tooltipster("hide");
		e.stopImmediatePropagation();
		return false;
	};

	var addElementTooltip = function(wrapper){
		if(!wrapper.hasClass("has-review-note")){
			
			var tooltipIcon = wrapper.find(".element-feedback-icon");
			tooltipIcon.data("page_notes", []);
			tooltipIcon.on(settings.clickEvent, function(e){
				pinnedElement = wrapper;
				if(tooltipIcon.hasClass("tooltip-open")){
					tooltipIcon.tooltipster("hide");
				}
				else{
					tooltipIcon.tooltipster("show", function(){					
						reposition(tooltipIcon.tooltipster('elementTooltip'));
					});
				}
				e.stopImmediatePropagation();
				e.stopPropagation();
				return false;
			});
			addTooltip(tooltipIcon);
			tooltipIcon.attr("title", "Element Feedback");
			wrapper.append(tooltipIcon);
			wrapper.addClass("has-review-note");
		}
	};

	var appendElementFeedback = function(pageInstance){
		$.each(pageInstance.page.notes, function(){
			if(this.element_id){
				var wrapper = $("#" + this.element_id + "_wrapper");
				addElementTooltip(wrapper);
			}
		});		
	};


	var findNote = function(id){
		for(var i = 0; i < _oActivePage.notes.length; i++){
			var note = _oActivePage.notes[i];
			if(note.id == id){
				return note;
			}
			for(var j = 0; j < note.notes.length; j++){
				if(note.notes[j].id == id){
					return note.notes[j];
				}
			};
		};
	}

	var removeNote = function(id){
		var newNotes = [];
		$.each(_oActivePage.notes, function(){			
			if(this.id != id){
				var newNoteNotes = [];
				for(var i = 0; i < this.notes.length; i++){
					if(this.notes[i].id != id){
						newNoteNotes.push(this.notes[i]);
					}
				};
				this.notes = newNoteNotes;
				newNotes.push(this)
			}						
		});
		_oActivePage.notes =  newNotes;
	}

	var getNotesForElement = function(id){
		var notes = [];
		$.each(_oActivePage.notes, function(){
			if(this.element_id == id){
				notes.push(this);
			}			
		});
		return notes;
	}
	
	return {
		init			: initialize		
	};
	
}(); //-> end FeedBackPanel Singleton

