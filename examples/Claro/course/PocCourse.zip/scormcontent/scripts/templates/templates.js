var isMobile = $("body").hasClass("mobile");
var isTablet =  $("body").hasClass("tablet");
var isOnline = $("body").hasClass("online");
if(!DKI){
	var DKI = {};
}
DKI.templates = {};

/************* Player Header and Footer *******************/
DKI.templates.header = "";
DKI.templates.footer = "";
if(isMobile || isTablet || isOnline){
	DKI.templates.header += '<div id="logo"></div>';
}
if(!isMobile){
	DKI.templates.footer += '<div id="info"> ' +
			'<span id="moduleName" tabindex="0"></span> ' +
			'<span id="objectName" tabindex="0"></span> ' +
		'</div> ' +
		'<div class="navButtonContainer"> ' +
			'<a ' + 
				'id="audioButton" ' +
				'class="navButton" ' + 
				'tabindex="0" ' + 
				'role="button" ' +
				'title="{{strings.index.audioButtonLabel}}" ' +
			'> ' +
				'<span class="button-left"></span> ' +
				'<span class="button-middle"><span class="button-label">{{strings.index.audioButtonLabel}}</span></span> ' +
				'<span class="button-right"></span> ' +	
			'</a> ' +
			'<a ' + 
				'id="replayButton" ' + 
				'class="navButton" ' + 
				'tabindex="0" ' + 
				'role="button" ' +
				'title="{{strings.index.replayButtonLabel}}" ' +
			'> ' +
				'<span class="button-left"></span> ' +
				'<span class="button-middle"><span class="button-label">{{strings.index.replayButtonLabel}}</span></span> ' +
				'<span class="button-right"></span> ' +	
			'</a> ' +
			'<div id="navButtons"> ' +
				'<span id="screenCount" tabindex="0"><span id="currentScreen">0</span> / <span id="totalScreens">0</span></span> ' +
				'<a ' + 
					'id="backButton" ' + 
					'class="navButton" ' + 
					'tabindex="0" ' + 
					'role="button" ' +
					'title="{{strings.index.previousButtonLabel}}" ' +
				'> ' +
					'<span class="button-left"></span> ' +
					'<span class="button-middle"><span class="button-label">{{strings.index.previousButtonLabel}}</span></span> ' +
					'<span class="button-right"></span> ' +	
				'</a> ' +
				'<a ' + 
					'id="forwardButton" ' + 
					'class="navButton" ' +
					'tabindex="0" ' + 
					'role="button" ' +
					'title="{{strings.index.nextButtonLabel}}" ' +
				'> ' +
					'<span class="button-left"></span> ' +
					'<span class="button-middle"><span class="button-label">{{strings.index.nextButtonLabel}}</span></span> ' +
					'<span class="button-right"></span> ' +
				'</a> ' +					
			'</div> ' +				
		'</div>	';
	DKI.templates.header += '<div class="navButtonContainer">' + 
		'<a ' +  
			'id="skipToContent" ' + 
			'class="navButton" ' + 
			'tabindex="1" ' + 
			'role="button" ' + 
			'title = "{{strings.index.skipToContent}}" ' + 
		'></a> ' + 

		'<a ' +  
			'id="resourceButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' + 
			'role="button" ' + 
			'title = "{{strings.index.resourcesButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.resourcesButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="glossaryButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title = "{{strings.index.glossaryButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.glossaryButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 
		'<a ' +  
			'id="transcriptButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' +  
			'title="{{strings.index.transcriptButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.transcriptButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 
		'<a ' +  
			'id="menuButton" ' +  
			'class="navButton" ' + 
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.menuButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.menuButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="exitButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.exitButtonLabel}}" ' + 
		'> ' +
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.exitButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 
		'</a> ' + 
	'</div>';
}
else if(isTablet){
	DKI.templates.header += '<a ' +  
		'id="skipToContent" ' +  
		'class="navButton" ' +  
		'tabindex="1" ' +  
		'role="button" ' + 
		'title = "{{strings.index.skipToContent}}" ' + 
	'></a> ' + 
	'<a ' +  
		'id="listButton" ' +  
		'class="navButton" ' +  
		'tabindex="1" ' +  
		'role="button" ' + 
		'title="{{strings.index.listButtonLabel}}" ' + 
	'> ' + 
		'<span>{{strings.index.listButtonLabel}}</span> ' + 
	'</a> ' + 
	'<div id="moreButtons"> ' + 
		'<a ' +  
			'id="exitButton" ' + 
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.exitButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.exitButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="menuButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.menuButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.menuButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="audioButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.audioButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.audioButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="resourceButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title = "{{strings.index.resourcesButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.resourcesButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="glossaryButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title = "{{strings.index.glossaryButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.glossaryButtonLabel}}</span> ' + 	
		'</a> ' + 
		'<a ' +  
			'id="transcriptButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.transcriptButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.transcriptButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="replayButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.replayButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.replayButtonLabel}}</span> ' + 
		'</a> ' + 
	'</div> ' + 
	'<span id="moduleName" tabindex="1"></span> ' + 
	'<span id="objectName" tabindex="1"></span> ' + 
	'<span id="screenCount" tabindex="1"><span id="currentScreen">0</span> / <span id="totalScreens">0</span></span> ' + 
	'<div id="navigationButtons"> ' + 
		'<a ' +  
			'id="backButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.previousButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.previousButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 
		'<a ' +  
			'id="forwardButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.nextButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.nextButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 	
	'</div>';
} 
else{
	DKI.templates.header += '<a ' + 
		'id="skipToContent" ' +  
		'class="navButton" ' +  
		'tabindex="1" ' +  
		'role="button" ' + 
		'title = "{{strings.index.skipToContent}}" ' + 
	'></a> ' + 
	'<a id="listButton" ' +  
			'class="navButton" ' + 
			'tabindex="1" ' +  
			'role="button" ' + 
			'aria-label="{{strings.index.listButtonLabel}}" ' + 
			'aria-haspopup="true" ' + 
			'aria-owns="moreButtons" ' + 
			'title="{{strings.index.listButtonLabel}}" ' + 
		'> ' + 
		'<span class="button-label">{{strings.index.listButtonLabel}}</span> ' + 
	'</a> ' + 
	'<div id="moreButtons"> ' + 
		'<a ' +  
			'id="exitButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.exitButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.exitButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="menuButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' + 
			'role="button" ' + 
			'title="{{strings.index.menuButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.menuButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="resourceButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title = "{{strings.index.resourcesButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.resourcesButtonLabel}}</span> ' + 
		'<a ' +  
			'id="glossaryButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title = "{{strings.index.glossaryButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.glossaryButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="transcriptButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.transcriptButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.transcriptButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="audioButton" ' +  
			'class="navButton" ' + 
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.audioButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.audioButtonLabel}}</span> ' + 
		'</a> ' + 
		'<a ' +  
			'id="replayButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' + 
			'title="{{strings.index.replayButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-label">{{strings.index.replayButtonLabel}}</span> ' + 
		'</a> ' + 
	'</div> ' + 
	'<span id="moduleName" tabindex="1"></span> ' + 
	'<span id="objectName" tabindex="1"></span> ' + 
	'<span id="screenCount" tabindex="1" role="region"><span id="currentScreen">0</span> / <span id="totalScreens">0</span></span> ' + 
	'<div id="navigationButtons"> ' + 
		'<a ' +  
			'id="backButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' + 
			'role="button" ' + 
			'aria-label="{{strings.index.previousButtonLabel}}" ' + 
			'title="{{strings.index.previousButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.previousButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 
		'<a ' +  
			'id="forwardButton" ' +  
			'class="navButton" ' +  
			'tabindex="1" ' +  
			'role="button" ' +  
			'aria-label="{{strings.index.nextButtonLabel}}" ' + 
			'title="{{strings.index.nextButtonLabel}}" ' + 
		'> ' + 
			'<span class="button-left"></span> ' + 
			'<span class="button-middle"><span class="button-label">{{strings.index.nextButtonLabel}}</span></span> ' + 
			'<span class="button-right"></span> ' + 	
		'</a> ' + 	
	'</div>';
}

/******************* End Screens **************************/
DKI.templates.endModule = '<div class="endScreenWrapper"> ' + 
		'<div class="endScreen"> ' + 
			'<h1 id="endMod_header" class="section header" tabindex="1"> ' + 
				'<p>{{strings.endMod.headerText}}</p> ' + 
				'<p><b id="endMod_moduleName" class="modname">{{strings.endMod.moduleNameLabel}}</b></p> ' + 
			'</h1> ' + 
			'<div id="endMod_status" class="section dki-section-panel status"> ' + 
				'<ul> ' + 
					'<li id="endMod_learningLine" class="dki-lineitem" tabindex="1"> ' + 
						'<span class="dki-label">{{strings.endMod.learningStatusLabel}}</span><strong id="endMod_learningStatus" class="dki-themeTextColor learningStatus">0%</strong> ' + 
					'</li> ' + 
					'<li id="endMod_scoreLine" class="dki-lineitem dki-lineitem-last" style="border-bottom:0px" tabindex="1"> ' + 
						'<div class="endMod_passStatus"></div> ' + 
						'<span class="dki-label">{{strings.endMod.testStatusLabel}}</span><strong id="endMod_testScore" class="dki-themeTextColor testScore">0%</strong> ' + 
						'<span class="endMod_passingScoreLine"> ' + 
							'<span class="dki-label">{{strings.endMod.passingScoreLabel}}</span> ' + 
							'<strong class="endMod_passingScore dki-themeTextColor"></strong> ' + 
						'</span> ' + 
					'</li> ' + 
				'</ul> ' + 
			'</div> ' + 
			'<div id="endMod_actions" class="section actions"> ' + 
				'<a class="endMod_learningLink" tabindex="1" role="button">{{strings.endMod.learningLinkLabel}}</a> ' + 
				'<a class="endMod_revisitLink" tabindex="1" role="button">{{strings.endMod.revisitContentButton}}</a> ' + 
				'<a class="endMod_testingLink disabled" id="" tabindex="1" role="button">{{strings.endMod.testingLinkLabel}}</a> ' + 
				'<a class="endMod_reviewLink" tabindex="1" role="button">{{strings.endMod.reviewTestButton}}</a> ' + 
			'</div> ' + 
			'<div id="endMod_testing" class="dki-section-panel testing"> ' + 
				'<div class="dki-title">&nbsp;</div> ' + 
				'<div class="dki-scroller"> ' + 				
				'</div> ' + 
			'</div> ' +
		'</div> ' + 
	'</div>';

DKI.templates.objectTestItem = 
	'<div class="dki-lineitem"> ' +
		'<div class="dki-modTitle" tabindex="1">{{object.name}}</div>' +
		'<div class="dki-modScore" tabindex="1">' +
			'{{strings.runtime.txtScore}} ' +
			'<span class="dki-themeTextColor">{{object.score}}% ({{object.points}}/{{object.totalWeight}} {{strings.runtime.txtPoints}})</span>' +
		'</div>' +
		'<div class="actions">' +
			'<a class="dki-modBtn subeoLink" data-subeoid="{{object.linkSubeoId}}" tabindex="1">{{strings.endMod.revisitContentButton}}</a>' +
		'</div>' +
	'</div>';

DKI.templates.endCourse = '<div class="endScreenWrapper"> ' + 
	'<div class="endScreen"> ' + 
		
		'<h1 id="endCourse_header" class="section header" tabindex="1"> ' + 
			'<p>{{strings.endCourse.headerLabel}}</p> ' + 
			'<p><b id="endCourse_courseName">{{contentApi "getCourseName"}}</b></p> ' + 
		'</h1> ' + 
		
		'<div id="endCourse_status" class="dki-section-panel status"> ' + 
			'<ul> ' + 
				'<li id="endCourse_learningLine" class="dki-lineitem" tabindex="1"> ' + 
					'<span class="dki-label">{{strings.endCourse.LearningStatusLabel}}</span><strong id="endCourse_learningStatus" class="dki-themeTextColor learningStatus">0%</strong> ' + 
				'</li> ' + 
				'<li id="testingLine" class="dki-lineitem dki-lineitem-last" tabindex="1"> ' + 
					'<div id="course_passing_status"></div> ' + 
					'<span id="endCourse_testingStatusLabel" class="dki-label">{{strings.endCourse.testingStatusLabel}}</span> ' + 
					'<strong id="endCourse_testingStatus" class="dki-themeTextColor testingStatus"> ' + 
					'<span id="course_score">0%</span> ' + 
					'</strong> ' + 
					'<span class="passing_score_container"> ' + 
						'<span class="dki-label passing_score_label">{{strings.endCourse.passingScoreLabel}}</span> ' +  
						'<span class="course_passing_score dki-themeTextColor">{{contentApi "getCoursePassMark"}} %</span> ' + 
					'</span> ' + 
				'</li> ' + 
			'</ul> ' + 
		'</div> ' + 

		'<div id="endCourse_actions" class="section actions"> ' + 
			'<a id="endCourse_certificateLink" class="disabled" tabindex="0" role="button">{{strings.endCourse.viewCertificate}}' + 
				'<span id="endCourse_certificateNotAvailable">{{strings.endCourse.certNotAvailable}}</span> ' + 
			'</a> ' + 
			'<a id="endCourse_bibliographyLink" tabindex="0" role="button">{{strings.endCourse.viewBibliography}}</a> ' + 
			'<a class="endCourse_revisitLink" tabindex="0" role="button">{{strings.endMod.revisitContentButton}}</a> ' + 
		'</div> ' + 
		
		'<div id="endCourse_testing" class="dki-section-panel testing" style="display:block;"> ' + 
			'<div class="dki-title">&nbsp;</div> ' + 
			'<div class="dki-scroller"> ' + 
				'<ul> ' + 
				'</ul> ' + 
			'</div> ' + 
		'</div> ' + 
	'</div> ' + 
'</div>';

/******************** UI Windows **************************/

//Search
DKI.templates.search ="<div id='searchBrowserContainer' class='loading windowContainer'>"+
	"<div id='searchbrowserHeader' class='browserHeader'>" +
		"<span class='headerTitle' tabindex='0'>{{strings.courseSearch.title}}</span>" +
		"<div class='browserCloseButton' tabindex='0'></div>"+
	"</div>" + 
	"<div class='browserContentContainer'>" +
		"<div id='resultList' class='panel browserList'>" +
			"<div class='searchContainer'>" +
			"<input id='courseSearchInput'class='searchInput' type='text' tabindex='0' placeholder='{{strings.courseSearch.inputPlaceholder}}'></input>" +
		"</div>" + 
		"<ul id='results' class='resultList'>" +
				"<li class='searchItem' data-filter='top' tabindex='0' title='{{strings.courseSearch.filterTop}}'><span class='icon top'></span><span class='filterTitle'>{{strings.courseSearch.filterTop}}</span></li>" + 
				"<li class='searchItem' data-filter='image' tabindex='0'title='{{strings.courseSearch.filterImages}}'><span class='icon image'></span><span class='filterTitle'>{{strings.courseSearch.filterImages}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='video' tabindex='0'title='{{strings.courseSearch.filterVideos}}'><span class='icon video'></span><span class='filterTitle'>{{strings.courseSearch.filterVideos}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='audio' tabindex='0'title='{{strings.courseSearch.filterAudio}}'><span class='icon audio'></span><span class='filterTitle'>{{strings.courseSearch.filterAudio}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='richMedia' tabindex='0'title='{{strings.courseSearch.filterRichMedia}}'><span class='icon richMedia'></span><span class='filterTitle'>{{strings.courseSearch.filterRichMedia}}</span><span class='resCount'></span></li>" +
				"<li class='division'></li>" +
				"<li class='searchItem' data-filter='text' data-istextitem='true' tabindex='0'title='{{strings.courseSearch.filterText}}'><span class='icon text'></span><span class='filterTitle'>{{strings.courseSearch.filterText}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='reference'  data-istextitem='true' tabindex='0'title='{{strings.courseSearch.filterReferences}}'><span class='icon reference'></span><span class='filterTitle'>{{strings.courseSearch.filterReferences}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='glossary'  data-istextitem='true' tabindex='0'title='{{strings.courseSearch.filterGlossaries}}'><span class='icon glossary'></span><span class='filterTitle'>{{strings.courseSearch.filterGlossaries}}</span><span class='resCount'></span></li>" + 
				"<li class='searchItem' data-filter='transcript'  data-istextitem='true' tabindex='0'title='{{strings.courseSearch.filterTranscripts}}'><span class='icon transcript'></span><span class='filterTitle'>{{strings.courseSearch.filterTranscripts}}</span><span class='resCount'></span></li>" + 
			"</ul>" +
			"<div class='sequential' title=''>"+
				"<span class='icon alert'></span><h3>{{strings.courseSearch.sequentialWarningTitle}}</h3><p>{{strings.courseSearch.sequentialWarningText}}</p>" +
			"</div>" +
		"</div>" +
		"<div class='panel details list'>" +
			"<div class='switchContainer'>" + 
				"<div class='listPanel'></div>" + 
				"<div class='propertiesPanel'>" +
					"<div tabindex='0' class='backNav'>" + 
						"<span class='icon backChevron'></span><span>{{strings.courseSearch.back}}</span>" +  
					"</div>" + 
					"<div class='overflowContainer'>" +
						"<div class='propertiesContent'></div>" + 
						"<div class='linksContainer'>" + 
							"<h3 class='linksTitle'></h3>" + 
							"<div class='links'></div>" + 
						"</div>"+
					"</div>" + 
				"</div>" +
			"</div>" + 
		"</div>" +
	"</div>" +
"</div>";

//Glossary
DKI.templates.glossaryPopup = '<div id="glossaryPopup" class="popupWindow loading">' +
			'<div class="glossaryPopupHeader">' +
				'<p id="glossaryPopupTerm" tabindex="0" ></p>' +
				'{{> jPlayerAudioSimple}}' + 
				'<div id="glossaryPopupClose" class="glossaryCloseButton" title="{{strings.runtime.buttonLabelClose}}" tabindex="0"></div>' +
			'</div><div class="sectionBreak"></div>' +
			'<div class="glossaryPopupBody">' +
				'<div id="glossaryPopupDefinitionContainer">' +
					'<div id="glossaryPopupDefinition" class="popupContent" tabindex="0"></div>' +
					'<div id="glossaryPopupSource" class="popupContent" tabindex="0"></div>'+
				'</div>' +
			'</div> <div class="sectionBreak"></div>' +
			'<div id="linkContainer">' +
				'<a id="viewBrowserLink" title="{{strings.glossary.viewTermTooltip}}"></a>' +
			'</div>'+
		'</div>' +
		'<div id="glossaryHoverDefinition" class="popupWindow"></div>';
DKI.templates.glossaryBrowser =  "<div id='glossaryBrowserContainer' class='loading windowContainer'>"+
	"<div id='browserHeader' class='browserHeader'>" +
		"<span id='glossaryBrowserTitle' class='headerTitle' tabindex='0'>{{strings.glossary.titleText}}</span>" +
		"<div id='glossaryBrowserClose' class='browserCloseButton' title='{{strings.runtime.buttonLabelClose}}' tabindex='0'></div>"+
	"</div>" +
	"{{#if mobile}}"  +
		"<div id='back' class='backButton' tabindex='0'> Back </div>" + 
		"<div class='searchContainer'>" +
				"<div class='searchIcon'/>" +
				"<input id='searchBox' class='searchInput' type='text'></input>" +
			"</div>" + 
	"{{/if}}" + 
	"<div id='glossaryContentContainer' class='browserContentContainer'>" +
		"<div id='termList' class='panel browserList'>" +
		"{{#unless mobile }}" + 
			"<div class='searchContainer'>" +
				"<div class='searchIcon'/>" +
				"<input id='searchBox' class='searchInput' type='text'></input>" +
			"</div>" + 
		"{{/unless}}" + 
	"<ul id='termUl' class='terms'></ul>" +
		"</div>" +
		"<div id='termDetails' class='panel details'>" +
			"<div class='detailsContent'>" +
				"<div>" +
					"<div id='term' tabindex='0'></div>{{> jPlayerAudioSimple}}" +
				'</div><div class="sectionBreak"></div>' +
				"<div id='definition' tabindex='0'></div><div class='sectionBreak'></div>" +
				"<div id='attribution' tabindex='0'></div>" +
			"</div>" +
		"</div>" +
	"</div>" +
"</div>";

//References
DKI.templates.citationPopup = "<div id='referencePopup' class='popupWindow loading'>" +
		"<div class='referencePopupHeader'>" +
			"<div id='referencePopupClose' class='glossaryCloseButton' tabindex='0' title='{{strings.runtime.buttonLabelClose}}'></div>" +
		"</div><div class='sectionBreak'></div>" +
		"<div class='referencePopupBody'>" +
			"<div id='referencePopupText' class='popupContent' tabindex='0'>" +
				"<div id='referenceTextContainer'></div>" +
			"</div>" +
		"<div class='sectionBreak'></div>" +
		"<div id='linkContainer'>" +
			"<span id='viewBibliographyLink' title = '{{strings.references.viewBibliography}}'tabindex='0'></span>" +
			"<div class='nav'><span class='previous citationNav' tabindex='0'></span><span class='counter' tabindex='0'></span><span class='next citationNav' tabindex='0'></span></div>" +
		"</div>"+
	"</div>";
DKI.templates.bibliography = "<div id='bibliographyContainer' class='loading windowContainer'>"+
		"<div id='bibliographyBrowserHeader' class='browserHeader'>" +
			"<span id='bibliographyTitle' class='headerTitle' tabindex='0'>{{strings.references.bibliographyWindowTitle}}</span>" +
			"<div id='bibliographyClose' class='browserCloseButton' tabindex='0'></div>"+
		"</div>" +
		"<div id='bibliographyContentContainer' class='browserContentContainer'></div>" +
	"</div>";

//Resources
DKI.templates.resourceBrowser = "<div id='resourceWindowContainer' class='loading windowContainer'>"+
		"<div id='searchHead' class='browserHeader'>" +
			"<span id='resourceBrowserTitle' class='headerTitle' tabindex='0'>{{strings.resources.resourceBrowserTitle}}</span>" +
			"<div id='resourceBrowserClose' class='browserCloseButton' title='{{strings.runtime.buttonLabelClose}}' tabindex='0'></div>"+
		"</div>" +
		"{{#if mobile}}" + 
			"<div id='resourceBack' class='backButton' tabindex='0'> Back </div>"  + 
			"<div class='searchContainer'>" +
					"<div class='searchIcon'/>" +
					"<input id='resourceSearchBox'class='searchInput' type='text' tabindex='0'></input>" +
				"</div>" + 
		"{{/if}}" + 
		"<div id='resourceContentContainer' class='browserContentContainer'>" +
			"<div id='resourceList' class='panel browserList'>" + 
		"{{#unless mobile}}" + 
			"<div class='searchContainer'>" +
				"<div class='searchIcon'/>" +
				"<input id='resourceSearchBox'class='searchInput' type='text' tabindex='0'></input>" +
			"</div>" + 
		"{{/unless}}" + 
		"<ul id='list' class='resultList'></ul>" +
			"</div>" +
			"<div id='resourceView' class='panel'>" +
				"<div class='detailsContent border'>" +
					"<div id='resourceDetails'>" +
						"<div id='resourceContent' tabindex='0'></div>" +
						"<div class='assetProperties'>" +
							"<div id='resourceTitle' tabindex='0'></div>" +
							"<div id='resourceDescription' tabindex='0'></div>" +
						"</div>" +
					"</div>" +
				"</div>" +
				
			"</div>" +
		"</div>" +
	"</div>";


DKI.templates.feedbackPanel = {
	tooltipContent: '<div class="feedback-wrapper">' +
				'{{> note.submit}}' +
				'<div class="feedback-notes">' +
					'{{#each o.notes}}' + 
						'{{> note}}' + 
					'{{/each}}' + 
				'</div>' +
			'</div>',
	toolbar:'<div id="reviewerTabContainer">' +
		'<span class="reviewerButtonLabel reviewerTabDraggableIcon"><i class="fa fa-arrows"></i></span>' +
		'<span class="reviewerButtonLabel" tabindex="0">Review Tools</span>' +
		'<div class="reviewerTabButton feedback-tooltip-icon" id="feedbackTab" title="View page feedback" tabindex="0"></div>' +
		'<div class="reviewerTabButton" id="pinFeedback" title="Select element for feedback" tabindex="0"></div>' +
		'<div class="reviewerTabButton" id="answerKey" title="See the test answer key" tabindex="0"></div>' +
		'<div class="reviewerTabButton" id="endReviewTab" title="End the review" tabindex="0"></div>' +
	'</div>',
	answerKey:
		'<div class="feedback-answer-key-wrapper">' +
			'<div id="closeAnswerKey" title="Close" tabindex="0"><i class="fa fa-close"></i></div>' +
			'{{#if assessment}}' +
			'<div class="status-container assessment">' +
				'<div class="status-header">Assessment Status</div>' +
				'<div class="status-details">' +
					'<div class="status-detail-wrapper totalQuestions">' +
						'<div class="status-detail-label">Total Questions:</div>' +
						'<div class="status-detail-value">{{assessment.totalQuestions}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper totalDelivered">' +
						'<div class="status-detail-label"># Delivered:</div>' +
						'<div class="status-detail-value">{{totalDelivered assessment}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper totalWeight">' +
						'<div class="status-detail-label">Total Weight:</div>' +
						'<div class="status-detail-value">{{assessment.totalWeight}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper currentScore">' +
						'<div class="status-detail-label">Current Score:</div>' +
						'<div class="status-detail-value">{{assessmentScore assessment}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper passMark">' +
						'<div class="status-detail-label">Pass Mark:</div>' +
						'<div class="status-detail-value">{{assessmentPassmark assessment}}</div>' +
					'</div>' +
				'</div>' +
			'</div>' +
			'{{/if}}' +
			'<div class="status-container question type-{{question.type}}">' +
				'<div class="status-header">Current Question</div>' +
				'<div class="status-details">' +
					'<div class="status-detail-wrapper title">' +
						'<div class="status-detail-label">Title:</div>' +
						'<div class="status-detail-value">{{question.title}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper type_label">' +
						'<div class="status-detail-label">Type:</div>' +
						'<div class="status-detail-value">{{question.type_label}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper weight">' +
						'<div class="status-detail-label">Weight:</div>' +
						'<div class="status-detail-value">{{question.weight}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper attempts">' +
						'<div class="status-detail-label"># of Attempts:</div>' +
						'<div class="status-detail-value">{{question.attempts}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper max_selections">' +
						'<div class="status-detail-label">Max Selections:</div>' +
						'<div class="status-detail-value">{{question.max_selections}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper partialScoring">' +
						'<div class="status-detail-label">Partial Scoring:</div>' +
						'<div class="status-detail-value">{{{questionPartialScoring question.parameters.scoringType}}}</div>' +
					'</div>' +
				'</div>' +
			'</div>' +
			'<div class="status-container question-choices">' +				
				'<div class="status-header">Choices</div>' +
				'<div class="status-details">' +
					'{{{questionChoices question}}}' +
				'</div>' +
			'</div>' +
			'<div class="status-container question-feedback">' +
				'<div class="status-header">Feedback</div>' +
				'<div class="status-details">' +
					'<div class="status-detail-wrapper correct-feedback">' +
						'<div class="status-detail-label">Correct:</div>' +
						'<div class="status-detail-value">{{{questionFeedback question.parameters.feedback.correct}}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper incorrect-feedback">' +
						'<div class="status-detail-label">Incorrect:</div>' +
						'<div class="status-detail-value">{{{questionFeedback question.parameters.feedback.incorrect}}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper partial-feedback">' +
						'<div class="status-detail-label">Partially Correct:</div>' +
						'<div class="status-detail-value">{{{questionFeedback question.parameters.feedback.partial}}}</div>' +
					'</div>' +
					'<div class="status-detail-wrapper incorrectAttempt-feedback">' +
						'<div class="status-detail-label">Incorrect Attempt:</div>' +
						'<div class="status-detail-value">{{{questionFeedback question.parameters.feedback.incorrectAttempt}}}</div>' +
					'</div>' +						
					'<div class="status-detail-wrapper partialAttempt-feedback">' +
						'<div class="status-detail-label">Partially Correct Attempt:</div>' +
						'<div class="status-detail-value">{{{questionFeedback question.parameters.feedback.partialAttempt}}}</div>' +
					'</div>' +
				'</div>' +
			'</div>' +			
		'</div>'
};

				

/********************** Partials **************************/

Handlebars.registerPartial('note.body',	
	'<div class="feedback-note-body-wrapper" data-id="{{id}}">' +
		'<div class="feedback-note-avatar" style="background-image: url({{enteredBy.avatarURL}});"></div>' +
		'<div class="feedback-note-details">' +
			'<div class="feedback-note-header">' +
				'<span class="feedback-name">{{enteredBy.first}} {{enteredBy.last}}</span>' +
				'<span class="feedback-date">{{simpleDate dateFiled}}</span>' +
			'</div>' +
			'<div class="feedback-note-body">{{{description}}}</div>' +
			'{{> note.edit}}' +
			'<a class="feedback-note-action upvote">+1</a>' +
			'<div class="feedback-note-rating">{{{rating}}}</div>' +			
		'</div>' +
	'</div>'
);

Handlebars.registerPartial('note.submit',
	'<div class="feedback-submit-wrapper">' + 
		'<div class="feedback-closeFeedbackTab" title="Close" tabindex="0"><i class="fa fa-close"></i></div>' +
		'<textarea class="txtArea-feedback" maxlength="1000"></textarea>' +	
		'<span>1000 characters</span>' +
		'<button class="feedback-btnSubmit">' + 
			'{{strings.buttonLabelSubmit}}' +
		'</button>' +
	'</div>');

Handlebars.registerPartial('note.reply',
	'<div class="feedback-reply-wrapper" data-parent_note_id="{{id}}">' +
		'<textarea class="txtArea-feedback" maxlength="1000"></textarea>' +
		'<span>1000 characters</span>' +
		'<button class="feedback-btnSubmit">' + 
			'Reply' +
		'</button>' +
	'</div>');
Handlebars.registerPartial('note.edit',
	'<div class="feedback-edit-wrapper" data-id="{{id}}">' +
		'<textarea class="txtArea-feedback" maxlength="1000">{{description}}</textarea>' +
		'<span>1000 characters</span>' +	
		'<button class="feedback-btnSubmit">' + 
			'Edit' +
		'</button>' +
	'</div>' +
	'<a class="feedback-note-action edit">edit</a>'
	);

Handlebars.registerPartial('note',
	'<div class="feedback-note-wrapper" data-id="{{id}}" data-enteredby="{{enteredBy.id}}">' +
		'{{> note.body}}' +
		'<div class="feedback-note-comments-wrapper">' +
			'{{#each notes}}{{> note.body}}{{/each}}' +
			'{{> note.reply}}' +
		'</div>' +
		'<div class="feedback-note-actions">' +
			'<a class="feedback-note-action reply">reply</a>' +
			'<a class="feedback-note-action delete">delete</a>' +
			'<a class="feedback-note-action resolve">resolve</a>' +
		'</div>' +
	'</div>');

Handlebars.registerPartial('jPlayerVideo',"<div id='{{videoAncestorId}}' class=\"jp-video\">" +
		"<div class=\"jp-type-single\">" +
			"<div id ='{{videoPlayerId}}' class=\"vidPlayer\" class=\"jp-video-player\"></div>" +
			"<div class=\"jp-video-play\">" +
				"<a class=\"jp-video-play-icon\">play</a>" +
			"</div>" +
			"<div class=\"jp-gui\">"+
				"<div class=\"jp-interface\">" +
					"<div class=\"jp-progress\">" +
						"<div class=\"jp-seek-bar\">" +
							"<div class=\"jp-play-bar\"></div>" +
						"</div>" +
					"</div>" +
					"<div class=\"jp-current-time\"></div>" +
					"<div class=\"jp-duration\"></div>" +
					"<div class=\"jp-controls-holder\">" +
						"<ul class=\"jp-controls\">" +
							"<li><a class=\"jp-play\" role=\"button\">play</a></li>" +
							"<li><a class=\"jp-pause\" role=\"button\">pause</a></li>" +
							"<li><a class=\"jp-transcript\" role=\"button\">transcript</a></li>" + 
							"<li><a class=\"jp-full-screen\" role=\"button\">full</a></li>" +
							"<li><a class=\"jp-restore-screen\" role=\"button\">restore</a></li>" +
							"<li><a class=\"jp-mute\" role=\"button\">mute</a></li>" +
							"<li><a class=\"jp-unmute\" role=\"button\">unmute</a></li>" +
						"</ul>" +
						 "<div class=\"jp-volume-bar\">" +
							"<div class=\"jp-volume-bar-value\"></div>" +
						"</div>" +
					"</div>" +
				"</div>" +
			"</div>" +
		"</div>" +
	"</div>");
Handlebars.registerPartial('jPlayerAudio', "<div id = '{{audioAncestorId}}' class='audioContainer mediaContainer jp-audio'>" +
		"<div id ='{{audioPlayerId}}' class='audioPlayer' class='jp-jplayer'></div>"+
		"<div class=\"jp-type-single\">"+
			"<div class=\"jp-gui jp-interface\">" +
				"<div class=\"jp-controls-holder\">" +
					"<ul class=\"jp-controls\">" +
						"<li><a class=\"jp-play\" tabindex=\"0\" role=\"button\">play</a></li>" +
						"<li><a class=\"jp-pause\" tabindex=\"0\" role=\"button\">pause</a></li>"+
						"<li><a class=\"jp-mute\" tabindex=\"0\" role=\"button\">mute</a></li>" +
						"<li><a class=\"jp-unmute\" tabindex=\"0\" role=\"button\">unmute</a></li>"+
					"</ul>" +
					"</div>" +
					"<div class=\"jp-progress\">" +
						"<div class=\"jp-seek-bar\">" +
							"<div class=\"jp-play-bar\"></div>" +
						"</div>" +
					"</div>" +
					"<div class='jp-time-holder'>" +
						"<div class='jp-current-time'></div>" +
						"<div class='jp-duration'></div>" +
				    "</div>" +
				"</div>" +
				"<div class=\"jp-no-solution\">" +
					"<span>No workee</span>" +
				"</div>" +
			"</div>"+
		"</div>" +
	"</div>");
Handlebars.registerPartial('jPlayerAudioSimple', '<div id="{{audioSimpleAncestorId}}" class="jp-basic">' +					
					"<div class=\"jp-type-single\">" +
						"<div id='{{audioSimplePlayerId}}' class=\"jp-audio\"></div>" +
						"<div class=\"jp-gui jp-basic jp-interface\">" +
							"<div class=\"jp-controls-holder\">" +
								"<ul class=\"jp-controls\">" +
									"<li><a class=\"jp-play\" tabindex=\"0\" role=\"button\">play</a></li>" +
									"<li><a class=\"jp-pause\" tabindex=\"0\" role=\"button\">pause</a></li>" +
								"</ul>" +
							"</div>" +
						"</div>" +
					"</div>" +
				'</div>');

/********************** Helpers **************************/
Handlebars.registerHelper("contentApi", function(member){
	if(contentApi && contentApi[member]){
		return typeof contentApi[member] === "function" ? contentApi[member]() : contentApi[member];
	}
	return "";
})
Handlebars.registerHelper("exists", function(member, options){
	var path = member.split(".");
	var exists = true;
	var curMem = this;
	for(var i=0; i < path.length; i++){
		if(typeof curMem[path[i]] === 'undefined'){
			exists = false;
			break;
		}
	}
	if(exists){
		return options.fn(this);
	}
	else{
		return options.inverse(this);
	}
});

Handlebars.registerHelper("simpleDate", function(date, options){
	var dtm = new Date(date);
	return dtm.getDate() + "/" + (dtm.getMonth()+1) + "/" + dtm.getFullYear();
});

Handlebars.registerHelper("assessmentScore", function(assessment, options){
	return assessment.getScore();
});
Handlebars.registerHelper("assessmentPassmark", function(assessment, options){
	var passmark = contentApi.getPassMark();
	if(assessment.module.passmark){
		passmark = assessment.module.passmark;
	}
	return passmark;
});

Handlebars.registerHelper("totalDelivered", function(assessment, options){
	var test = dataStorage.loadTest(assessment.module, false);
	return test.questions.length;
});

Handlebars.registerHelper("questionPartialScoring", function(type, options){
	var partialScoring = "On";
	if((type == 0 && !playerBehaviour.partialScoring) || type == 2){
		partialScoring = "Off";
	}	
	return partialScoring;
});

Handlebars.registerHelper("questionChoices", function(question, options){	
	var html = '';
	if(question.type == 1){
		html += '<div class="status-detail-wrapper answer">';
		html += '<div class="status-detail-label">Answer:</div>';
		html += '<div class="status-detail-value">' + question.options[0].parameters.correct + '</div>';
		html += '</div>';
	}
	else if(question.type == 2){
		html += '<table>';
		html += '<tr>';
		html += '<th>Letter</th>';
		html += '<th>Correct?</th>';
		html += '<th>Random?</th>';
		html += '<th>Feedback</th>';
		html += '</tr>';
		for(var i = 0; i < question.options.length; i++){
			var option = question.options[i];
			var wrapper = $("#" + option.element_id + "_wrapper");
			html += '<tr class="question-option-element-link" data-id="' + option.element_id + '">';			
			html += '<td>' + wrapper.find(".optionNumber").text() + '</td>';
			html += '<td>' + option.parameters.correct + '</td>';
			html += '<td>' + option.parameters.randomized + '</td>';
			html += '<td><div class="option-feedback" title="' + option.parameters.feedback + '">' + option.parameters.feedback + '</div></td>';
			html += '</tr>';
		}
		html += '</table>';
	}
	else if(question.type == 4){
		html += '<table>';
		html += '<tr>';
		html += '<th>Letter</th>';
		html += '<th>Correct Values</th>';
		html += '<th>Feedback</th>';
		html += '</tr>';
		for(var i = 0; i < question.options.length; i++){
			var option = question.options[i];
			var wrapper = $("#" + option.element_id + "_wrapper");
			html += '<tr class="question-option-element-link" data-id="' + option.element_id + '">';			
			html += '<td>' + wrapper.find(".optionNumber").text() + '</td>';
			html += '<td>' + option.parameters.correctValues + '</td>';
			html += '<td><div class="option-feedback" title="' + option.parameters.feedback + '">' + option.parameters.feedback + '</div></td>';
			html += '</tr>';
		}
		html += '</table>';
	}
	else if(question.type == 5){
		html += '<table>';
		html += '<tr>';
		html += '<th>Letter</th>';
		html += '<th>Correct Value</th>';
		html += '<th>Feedback</th>';
		html += '</tr>';
		for(var i = 0; i < question.options.length; i++){
			var option = question.options[i];
			var wrapper = $("#" + option.element_id + "_wrapper");
			html += '<tr class="question-option-element-link" data-id="' + option.element_id + '">';			
			html += '<td>' + wrapper.find(".optionNumber").text() + '</td>';
			html += '<td>' + option.parameters.correctValue + '</td>';
			html += '<td><div class="option-feedback" title="' + option.parameters.feedback + '">' + option.parameters.feedback + '</div></td>';
			html += '</tr>';
		}
		html += '</table>';
	}
	else if(question.type == 6){
		html += '<table>';
		html += '<tr>';
		html += '<th>Draggable</th>';
		html += '<th>Correct Target</th>';
		html += '</tr>';
		for(var i = 0; i < question.options.length; i++){
			var option = question.options[i];
			var wrapper = $("#" + option.element_id + "_wrapper");
			var wrapperTitle = wrapper.data("title");
			if(wrapperTitle == ""){
				wrapperTitle = wrapper.data("meta");
			}
			html += '<tr>';

			html += '<td class="question-option-element-link" data-id="' + option.element_id + '">' + wrapperTitle + '</td>';
			html += '<td>';
			for(var j = 0; j < option.parameters.correctTargets.length; j++){
				var target = $(".dki-authoring-element[data-dragdropid='" + option.parameters.correctTargets[j] + "']");
				var targetTitle = target.data("title");
				if(targetTitle == ""){
					targetTitle = target.data("meta");
				}
				html += '<div class="question-option-element-link" data-id="' + target.data("id") + '">' + targetTitle + '<div/>';
			}
			html += '</td>';
			html += '</tr>';
		}
		html += '</table>';
	}
	
	
	return html;
});

Handlebars.registerHelper("questionFeedback", function(feedback, options){	
	var html = feedback.text;
	if(feedback.useDefault.toString() == "true"){
		html = "<i>Using course default</i>";
	}
	else if(feedback.text == ""){
		html = "<i>None supplied by author</i>";
	}
	return html;
});