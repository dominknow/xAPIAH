(function($){
	var doneLoading = false;
	var shuffle = function(a) {
		var j, x, i;
		for (i = a.length; i; i -= 1) {
			j = Math.floor(Math.random() * i);
			x = a[i - 1];
			a[i - 1] = a[j];
			a[j] = x;
		}
		return a;
	};
	var getRandomInt = function (min, max) {
	    return Math.floor (Math.random () * (max - min + 1) ) + min;
	}

	var messages = shuffle([
		"Optimizing the images",
		"Rendering Pages",
		"Building the Table of Contents",
		"Fine-tuning the audio",
		"Asking the questions",
		"Experiencing the API",
		"Analyzing external resources",
		"Indexing the content",
		"Scrubbing the videos",
		"SCORMing the LMS",
		"Hoisting the headers",
		"Dropping the footers",
		"Generating HTML5",
		"Citing the references",
		"Labeling the images",
		"Sorting the tables",
		"Constructing the navigation",
		"Powerwashing the server",
		"Cooking eggs on CPU",
		"Preparing the loading entertainment",
		"Replenishing the cash",
		"Loading monkeys",
		"Releasing the hamsters",
		"Loading elevator music",
		"Avoiding the white rabbit",
		"Validating content effectiveness",
		"Polishing the pixels",
		"Breeding the bits and bytes",
		"Adjusting the flux capacitor",
		"Increasing speed to 88MPH",
		"Looking for answers",
		"Starting the large hadron collider",
		"Drafting architecture",
		"Verifying patience",
		"Requesting permission",
		"Looking behind you for problems",
		"Removing any incorrect data",
		"Looking for General Failure",
		"Testing for perfection",
		"Creating infinite loop",
		"Loading self awareness",
		"Beaming up special commands",
		"Loading enchanted forest",
		"Centralizing the processing units",
		"Randomizing access memory",
		"Calculating the odds",
		"Charging capacitors to 1.21 jiggawatts",
		"Found the content we are looking for",
		"Giving it all we've got",
		"Increasing lemon and electrode power grid",
		"Applying class to your style",
		"Centralizing the intelligence",
		"Nulling the voids",
		"Voiding the nulls",
		"Constructing additional pylons",
		"Sweeping bugs under the rug",
		"Dusting off the servers",
		"Setting dials to 11",
		"Finding the any key",
		"Turning it off and on again",
		"Crossing the t's",
		"Dotting the i's",
		"Kerning the fonts",
		"Sizing the ems",
		"Copying assets",
		"Rendering actions",
		"Updating libraries",
		"Creating glossary",
		"Analyzing page structure",
		"Creating menu",
		"Caching the elements",
		"Validating communication libraries",
		"Pixelating the dimensions",
		"Validating content pages",
		"Verifying questions",
		"Confirming publish settings",
		"Checking document publish status",
		"Checking links and resources",
		"Loading theme",
		"Rendering metadata",
		"Creating JavaScript libraries",
		"Updating content API",
		"Clarofying the settings",
		"Capturing current status",
		"Updating course history",
		"Checking for PENS settings",
		"Flushing the cache",
		"Optimizing the learnings",
		"De-practicing the practice questions",
		"Stronging the bolds",
		"Scrubbing the video",
		"Emphasizing the italics",
		"Classing the styles",
		"Reversing arrays through the deflector",
		"Zooming and enhancing",
		"De-Canadianizing the Colours",
		"Charging the learning particles",
		"De-verticalizing the vertical experience",
		"Changing ribbons on millions of monkey's typewriters",
		"Hand picking the theme with a velvet glove",
		"Dusting off the glossaries",
		"Carving the pages from a block of rich mahogany",
		"Transcribing the page notes into cuneiform tablets",
		"A team of robots is placing the markers",
		"Flowing into the preview",
		"Authorizing the notifications",
		"Showing the actions",
		"Locating the required gigapixels to render",
		"Programming the flux capacitor",
		"Feeding the server hamsters",
		"Calculating the viscosity ratio",
		"640K ought to be enough for anybody",
		"Aligning satellites",
		"Loading humorous messages",
		"Warming up Large Hadron Collider",
		"Paying the magic elves",
		"Estimating the time",
		"Showing the time escaped",
		"Allocating the proper amount of time for a coffee break",
		"Adjusting the nut behind the keyboard",
		"Charging Schneider particles",
		"Securing the internet",
		"Downloading the internet",
		"Optimizing scanners"
	]);
	var disabler = new DKI.disabler({
		showSpinner: true,
		"className": "previewLoader"
	});
	var interval, timeout;
	disabler.show();
	var ctr = 0;

	var showMessage = function(){
		var message = messages[ctr];
		var time = getRandomInt(2000, 7500);
		var intCtr = 0;
		interval = setInterval(function(){

			if(intCtr == 7){
				return;
			}
			intCtr++;
			var newMessage = message;
			for(var i = 0; i < intCtr; i++){
				if(i < 6){
					newMessage += ".";
				}
			}
			for(var i = 0; i < 6-intCtr; i++){
				newMessage += "&nbsp;";
			}
			if(intCtr == 7 || doneLoading){
				newMessage += "<i style='color:green;' class='fa fa-check'/>";
			}
			else{
				newMessage += "<i style='color:transparent;' class='fa fa-check'/>";			
			}
			disabler.setText(newMessage);
			if(doneLoading){
				clearInterval(interval);
				clearTimeout(timeout);
				setTimeout(function(){
					disabler.hide(true);
				})			
			}
		}, time / 7);
		timeout = setTimeout(function(){
			if(ctr < messages.length-1){
				ctr++;
			}
			else{
				ctr = 0;
			}
			clearInterval(interval);
			if(doneLoading){
				disabler.hide();
			}
			else{
				showMessage();
			}
		}, time + 500);
	}
	showMessage();
	


	$(document).on(DKI.ContentPage.events.started, function(){doneLoading=true;});	
	$(document).on(DKI.EndCourse.events.started, function(){doneLoading=true;});
	$(document).on(DKI.EndModule.events.started, function(){doneLoading=true;});
	$(document).on(DKI.EndTest.events.started, function(){doneLoading=true;});
	$(document).on("loadError", function(){
		clearInterval(interval);
		clearTimeout(timeout);		
		var error = new DKI.disabler({
			showSpinner: false,
			"text": "An error has occurred loading the preview. Please contact support."
		});
		disabler.hide();
		error.show();
	});
})(jQuery);
