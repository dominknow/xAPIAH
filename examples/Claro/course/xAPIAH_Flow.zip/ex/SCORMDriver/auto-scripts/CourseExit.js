/*! -- File: CourseExit.js ( Input 0 ) -- */
function niExit(){var a=window.parent;confirm("Are You Sure You Wish To Exit This Course?")&&a.ConcedeControl()};