/*! -- File: AutoCompleteSCO.js ( Input 0 ) -- */
function SetSCOComplete(){var a=window.parent;a.SetReachedEnd();a.CommitData()}SetSCOComplete();