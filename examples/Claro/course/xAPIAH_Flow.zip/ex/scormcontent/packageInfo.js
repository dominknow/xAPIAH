/*! -- File: packageInfo.js ( Input 0 ) -- */
var DKI_Package_Info={claro_url:"http://dki-surface07.dominknow.com/Flow/",publishing_profile_id:"770CC47F-E81D-328C-3B32-20B84AF6EA15"};