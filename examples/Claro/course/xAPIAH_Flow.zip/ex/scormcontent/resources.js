/*! -- File: resources.js ( Input 0 ) -- */
DKI.resources=[];