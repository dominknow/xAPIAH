/*! -- File: references.js ( Input 0 ) -- */
DKI.references={references:{},citations:{},referenceOrder:[],lastOrder:0};